<template>
    <img class="md:w-48 w-40" src="https://marrakechdreamballooning.com/wp-content/uploads/2018/09/Artboard-1logo-h-padding.png" alt="logo" >
</template>
